package com.example.asus.divar.Activity;

import android.annotation.SuppressLint;
import android.support.annotation.NonNull;
import android.support.design.internal.BottomNavigationItemView;
import android.support.design.internal.BottomNavigationMenuView;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.asus.divar.Fragment.FourFragment;
import com.example.asus.divar.Fragment.OneFragment;
import com.example.asus.divar.Fragment.ThreeFragment;
import com.example.asus.divar.Fragment.TwoFragment;
import com.example.asus.divar.R;

import java.lang.reflect.Field;
import java.text.MessageFormat;

public class MainActivity extends AppCompatActivity
{
    private TextView textView;
    private BottomNavigationView bottomNavigationView;
    private FrameLayout frameLayout;
    private FloatingActionButton fab;

    @SuppressLint("RestrictedApi")
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = findViewById(R.id.txt_main_act);
        bottomNavigationView = findViewById(R.id.bnv_main_act);
        frameLayout = findViewById(R.id.frmContainer_main_act);
        fab = findViewById(R.id.fab_main_act);

        FourFragment fourFragment = new FourFragment();
        switchToFragment(fourFragment);


        bottomNavigationView.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener()
        {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem menuItem)
            {
                switch (menuItem.getItemId())
                {
                    case R.id.item_1:
                        //textView.setText("دیوار من");
                        OneFragment oneFragment = new OneFragment();
                        switchToFragment(oneFragment);
                        return true;
                    case R.id.item_2:
                        //textView.setText("چت");
                        TwoFragment twoFragment = new TwoFragment();
                        switchToFragment(twoFragment);
                        return true;
                    case R.id.item_3:
                        //textView.setText("دسته بندی ها");
                        ThreeFragment threeFragment = new ThreeFragment();
                        switchToFragment(threeFragment);
                        return true;
                    case R.id.item_4:
                        //textView.setText("دیوار تهران");
                        FourFragment fourFragment = new FourFragment();
                        switchToFragment(fourFragment);
                        return true;
                }
                return false;
            }

        });

        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this, "دکمه افزودن کلیک شد", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void switchToFragment(Fragment fragment)
    {
        FragmentManager manager = getSupportFragmentManager();
        manager.beginTransaction().replace(R.id.frmContainer_main_act, fragment).commit();
    }

}
